OSH Tracker PWA
================

This folder contains an installable Progressive Web App. It must be served from an HTTPS website (or localhost) for Chrome's Install/Add to Home Screen option and offline service worker to work.

Files:
- index.html
- manifest.webmanifest
- sw.js
- icon-192.png
- icon-512.png

Quick deployment using GitHub Pages:
1. Sign in to GitHub and create a new public repository, e.g. osh-tracker.
2. Upload all five files from this folder to the repository root.
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
5. Wait for GitHub Pages to publish the HTTPS site.
6. Open the published URL in Chrome on Android.
7. Chrome menu ⋮ > Install app (or Add to Home screen).

Important:
- Data stays in that browser's local storage on that phone. It is not synced.
- Export a JSON backup regularly from the app.
- Do not clear Chrome site data unless you have a backup.
- This is a task tracker, not an official JKKP system.
